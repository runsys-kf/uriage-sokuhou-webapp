import Layout from "@/components/Layout";
import { Button } from "@mui/material";
import { useRouter } from "next/router";

const Home = () => {
    const router = useRouter();
    return (<>
        <Layout title="自空ナビ">

            <h1>自空ナビのページ</h1>
        </Layout>
    </>
    );
};
export default Home;