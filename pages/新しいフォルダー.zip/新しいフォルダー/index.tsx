import Layout from "@/components/Layout";
import { Button } from "@mui/material";
import { useRouter } from "next/router";

const Home = () => {
  const router = useRouter();
  return (<>
    <Layout title="売上速報 | 自空ナビ">
      <div className="bg-white border rounded-lg p-2 px-5 py-5 h-full m-10 max-w-md">
        <Button
          className="bg-blue-500 hover:bg-blue-800 text-white w-full p-1 md:p-1 mb-5"
          onClick={() => router.push("/app1/")}>売上速報</Button>
        <Button
          className="bg-blue-500 hover:bg-blue-800 text-white w-full p-1 md:p-1"
          onClick={() => router.push("/app2/")}>自空ナビ</Button>
      </div>
    </Layout>
  </>
  );
};
export default Home;